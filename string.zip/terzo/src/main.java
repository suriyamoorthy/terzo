import java.util.Arrays;
import java.util.Locale;

public class main {

    public static void main(String[] args) {

        String learn  = "java learn cloud app";
        System.out.println(learn);
        //System.out.println(learn.trim());
        //System.out.println(learn.toUpperCase());
        //System.out.println(learn.startsWith("j"));

    }
}
