public class main {

    public static void main(String[] args) {

        byte number = 126;
        short number1 = 150;
        int number2 = 123456789;
        long number3 = 12348567L;
        float number4 = 11.4f;
        double number5 = 1234.83458;
        char alphabet = 'a' ;
        boolean bool = true;
        System.out.println(bool);
        System.out.println(number1);
        System.out.println(number2);
        System.out.println(number5);


    }
}
