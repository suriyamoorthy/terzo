import java.util.Arrays;
import java.util.Locale;

public class main {

    public static void main(String[] args) {
    int ageOfPerson = 30;
    int numberOne = 2000;
        System.out.println(ageOfPerson);
        System.out.println(numberOne);
    }
}
